export class CategoriaModel {
    id: string;
    descripcion: string;
    usuario: string;
}