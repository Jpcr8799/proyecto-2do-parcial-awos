export class UsuarioModel {
    id: string;
    nombre: string;
    apellido: string;
    email: string;
    password: string;
}