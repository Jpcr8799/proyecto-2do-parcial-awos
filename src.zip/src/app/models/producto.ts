export class ProductoModel {
    id: string;
    nombre: string;
    categoria: string;
    precio: string;
    usuario: string;
}